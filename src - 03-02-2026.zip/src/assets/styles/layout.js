import { StyleSheet } from "react-native";

export const layoutStyles = StyleSheet.create({
    vCenter: {
        alignItems: 'center'
    }
})