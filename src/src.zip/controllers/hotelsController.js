import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProperties } from "@store/slices/propertySlice";

export default function useHotelsController() {

    const [sortValue, setSortValue] = useState(0);
    const [page, setPage] = useState(1);
    const itemsPerPage = 10;

    const dispatch = useDispatch();
    const { loading, properties, count, filterValues, searchVal, cityName } = useSelector((state) => state.property);
    // console.log('loading', loading)
    // console.log('count', count)
    // console.log('filterValues', filterValues)
    // console.log('searchVal', searchVal)
    // console.log('cityName', cityName)

    useEffect(() => {
        if (!dispatch) return;

        const filters = { ...filterValues };

        /* ------------------ SORT ------------------ */
        const byPrice =
            sortValue === 1
                ? "order_by=price&order_direction=desc"
                : sortValue === 2
                    ? "order_by=price&order_direction=asc"
                    : sortValue === 3
                        ? "order_by=rating&order_direction=desc"
                        : "order_direction=asc";

        /* ------------------ LOCATION (LAT/LONG) ------------------ */
        if (filters?.latlongFilter?.lat && filters?.latlongFilter?.long) {
            const { lat, long } = filters.latlongFilter;

            dispatch(
                fetchProperties(
                    `?order_direction=asc&lat=${lat}&long=${long}&page=${page}&limit=${itemsPerPage}`
                )
            );
            return;
        }

        /* ------------------ QUERY ------------------ */
        let query = "";
        if (searchVal) {
            query = `&query=${searchVal}`;
        } else if (cityName) {
            query = `&query=${cityName}`;
        }

        /* ------------------ OTHER FILTERS ------------------ */
        const locality =
            filters?.localityFilter?.length > 0
                ? `&pin_code=${filters.localityFilter}`
                : "";

        const propertyType = filters?.propertyCategoryFilter?.length
            ? `&property_type=${filters.propertyCategoryFilter.toString()}`
            : "";

        const roomType = filters?.roomCategoryFilter?.length
            ? `&room_type=${filters.roomCategoryFilter.toString()}`
            : "";

        const travellerChoice = filters?.travellerChoice?.length
            ? `&traveller_choice=${filters.travellerChoice.toString()}`
            : "";

        /* ------------------ FINAL URL ------------------ */
        const finalParams =
            `?${byPrice}` +
            locality +
            query +
            propertyType +
            roomType +
            travellerChoice +
            `&page=${page}&limit=${itemsPerPage}`;

        dispatch(fetchProperties(finalParams));

    }, [dispatch, sortValue, filterValues, cityName, searchVal, page, itemsPerPage]);


    const getAverageRating = (ratings = []) => {
        if (!ratings.length) return 0;
        const total = ratings.reduce(
            (acc, curr) => acc + curr.rating,
            0
        );
        return (total / ratings.length).toFixed(1);
    };

    const ALL_SLOTS = ["3Hrs", "6Hrs", "9Hrs", "FullDay"];

    const mergeAllSlotsForDate = (statusData, priceData, date, slotRegularPrices) => {
        const statusSlots = statusData?.[date] || [];
        const priceSlots = priceData?.[date] || [];

        return ALL_SLOTS.map(slot => {
            const statusItem = statusSlots.find(s => s.slot === slot);
            const priceItem = priceSlots.find(p => p.slot === slot);

            // Fallback prices
            let fallbackPrice = null;
            switch (slot) {
                case "3Hrs":
                    fallbackPrice = slotRegularPrices?.threeHrPrice || 0;
                    break;
                case "6Hrs":
                    fallbackPrice = slotRegularPrices?.sixHrPrice || 0;
                    break;
                case "9Hrs":
                    fallbackPrice = slotRegularPrices?.nineHrPrice || 0;
                    break;
                case "FullDay":
                    fallbackPrice = slotRegularPrices?.regularPrice || 0;
                    break;
            }

            return {
                slot,
                status: statusItem ? statusItem.status : "Available",
                price: Number(priceItem?.price || fallbackPrice)
            };
        });
    };

    const safeParse = (value) => {
        try {
            if (!value) return {};
            if (typeof value === "object") return value;
            if (typeof value === "string") return JSON.parse(value);
            return {};
        } catch (e) {
            console.error("Parse error:", value);
            return {};
        }
    };

    return {
        properties,
        count,
        loading,
        getAverageRating,
        mergeAllSlotsForDate,
        safeParse
    };
}
