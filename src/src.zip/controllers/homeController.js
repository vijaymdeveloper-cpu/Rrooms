import { useEffect, useState, useMemo } from "react";
import services from "@api/services";
import { POPULAR_CITIES, CITY_PRIORITY } from "@constants";
import { useDispatch, useSelector } from "react-redux";
import { setCity, setSearch, setFilter } from '@store/slices/propertySlice';
import { useNavigation } from "@react-navigation/native";
import { fetchProperties } from "@store/slices/propertySlice";
// import Geolocation from 'react-native-geolocation-service';
// import { requestLocationPermission } from '@utils/permissions';

const useHomeController = () => {

    const [cities, setCities] = useState([]);
    const [loading, setLoading] = useState(false);
    const [locationData, setLocationData] = useState("");

    const dispatch = useDispatch();
    const navigation = useNavigation();
    const { properties } = useSelector((state) => state.property);

    const fetchAllCities = async () => {
        try {
            setLoading(true);
            const res = await services.allCitiesService();
            if (res?.data?.status) {
                setCities(res?.data?.data || []);
            }
        } catch (error) {
            console.log("Fetch cities error:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllCities();
        dispatch(fetchProperties('?order_direction=asc&query=Lucknow&page=1&limit=10'))
    }, []);

    const filterCities = useMemo(() => {
        const filtered = cities?.filter((item) =>
            POPULAR_CITIES?.includes(item.name)
        );

        return filtered.sort((a, b) => {
            const indexA = CITY_PRIORITY.indexOf(a.name);
            const indexB = CITY_PRIORITY.indexOf(b.name);

            if (indexA !== -1 && indexB !== -1) {
                return indexA - indexB;
            }
            if (indexA !== -1) return -1;
            if (indexB !== -1) return 1;

            return a.name.localeCompare(b.name);
        });
    }, [cities]);

    const handleCityPress = (item) => {
        dispatch(setCity(item.name))
        dispatch(setSearch(item.name));
        dispatch(setFilter({ travellerChoice: '' }));
        dispatch(
            setFilter({
                cityId: item.id,
                latlongFilter: { lat: null, long: null },
            })
        );
        navigation.navigate('Hotels')
    }

    const handleFilterByTravelChoise = (item) => {
        console.log('item', item)
        dispatch(setCity(''))
        dispatch(setSearch(""));
        dispatch(setFilter({ travellerChoice: [item.id] }));
        navigation.navigate('Hotels')
    }


    // useEffect(() => {
    //     Geolocation.setRNConfiguration({
    //         locationProvider: 'playServices', // 👈 force Fused Provider
    //     });
    // }, []);

    // useEffect(() => {
    //     const init = async () => {
    //         await Geolocation.requestAuthorization('whenInUse');

    //         const hasPermission = await requestLocationPermission();
    //         if (hasPermission) {
    //             getCurrentLocation();
    //         }
    //     };

    //     init();
    // }, []);




    // const getCurrentLocation = () => {
    //     console.log('one');

    //     Geolocation.getCurrentPosition(
    //         position => {
    //             console.log('two');
    //             const { latitude, longitude } = position.coords;
    //             console.log('✅ Lat:', latitude, 'Lng:', longitude);
    //         },
    //         error => {
    //             console.log('❌ Location error:', error.code, error.message);
    //         },
    //         {
    //             enableHighAccuracy: false,
    //             timeout: 30000,
    //             maximumAge: 0,
    //             forceRequestLocation: true,
    //             showLocationDialog: true,
    //         }
    //     );
    // };


    // useEffect(() => {
    //     const initLocation = async () => {
    //         const hasPermission = await requestLocationPermission();
    //         console.log('hasPermission', hasPermission)

    //         if (hasPermission) {
    //             getCurrentLocation();
    //         } else {
    //             console.log('Location permission denied');
    //         }
    //     };

    //     initLocation();
    // }, []);

    // const showPosition = (position) => {
    //     setLocationData(position?.coords);
    // };

    // const handleNearByPress = async () => {
    //     const { latitude, longitude } = locationData;
    //     dispatch(setFilter({ latlongFilter: { lat: latitude, long: longitude } }));
    //     navigation.navigate('Hotels')
    // };

    return {
        cities,
        filterCities,
        loading,
        properties,
        fetchAllCities,
        handleCityPress,
        handleFilterByTravelChoise,
        // handleNearByPress
    };
};

export default useHomeController;
