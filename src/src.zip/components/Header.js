import React from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { useNavigation } from "@react-navigation/native";
import { useSelector } from "react-redux";
import { baseImgUrl } from '@api/client'

const Header = ({ showBack = false }) => {

    const navigation = useNavigation();

    const { userDetail } = useSelector((state) => state.auth);

    return (
        <View style={styles.header}>
            {showBack ? (
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Icon name="arrow-back" size={24} />
                </TouchableOpacity>
            ) : (
                <View>
                    <Image
                        source={require("@assets/images/logo.png")}
                        style={styles.logo}
                    />
                </View>
            )}
            <Text style={styles.textLogo}>
                <Text style={{ color: '#ff9d25' }}>R</Text>ROOMS
            </Text>
            <View>
                <Image
                    source={{ uri: `${baseImgUrl}${userDetail?.profileImage}` }}
                    style={styles.profile}
                />
            </View>
        </View>
    );
};

export default Header;


const styles = StyleSheet.create({
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10
    },
    textLogo: {
        color: '#3C4043',
        fontWeight: '900',
        fontSize: 22
    },
    logo: {
        width: 32,
        height: 40,
    },
    profile: {
        width: 40,
        height: 40,
        borderRadius: 20,
    }
});