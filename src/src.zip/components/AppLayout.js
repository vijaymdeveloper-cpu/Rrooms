import { ImageBackground, StyleSheet, StatusBar, View, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";

const AppLayout = ({ children, background = require("@assets/images/bg21.jpg"), statusBarColor = "dark-content" }) => {

  const isImage = typeof background === "number" || background?.uri;

  const Wrapper = isImage ? ImageBackground : View;

  useFocusEffect(
    useCallback(() => {
      StatusBar.setBarStyle(statusBarColor);
      if (Platform.OS === "android") {
        StatusBar.setBackgroundColor("transparent");
        StatusBar.setTranslucent(true);
      }
    }, [statusBarColor])
  );

  return (
    <Wrapper
      {...(isImage && {
        source: background,
        resizeMode: "cover",
      })}
      style={[
        styles.viewArea,
        !isImage && background,
      ]}
    >
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        {children}
      </SafeAreaView>
    </Wrapper>
  );
};

export default AppLayout;

const styles = StyleSheet.create({
  viewArea: {
    flex: 1,
  },
  safe: {
    flex: 1,
    paddingTop: 10,
  },
});
