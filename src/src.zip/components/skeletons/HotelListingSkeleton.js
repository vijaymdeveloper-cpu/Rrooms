import React, { useRef, useEffect } from "react";
import {
    View,
    StyleSheet,
    Animated,
    Dimensions,
} from "react-native";

const { width } = Dimensions.get("window");

const SkeletonBox = ({ style }) => {
    const shimmer = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.loop(
            Animated.timing(shimmer, {
                toValue: 1,
                duration: 1200,
                useNativeDriver: true,
            })
        ).start();
    }, []);

    const translateX = shimmer.interpolate({
        inputRange: [0, 1],
        outputRange: [-width, width],
    });

    return (
        <View style={[styles.skeleton, style]}>
            <Animated.View
                style={[
                    styles.shimmer,
                    { transform: [{ translateX }] },
                ]}
            />
        </View>
    );
};

const HotelCardSkeleton = () => {
    return (
        <View style={styles.card}>
            {/* Image */}
            <SkeletonBox style={styles.image} />

            {/* Tags */}
            <View style={styles.tagRow}>
                <SkeletonBox style={styles.tag} />
                <SkeletonBox style={styles.discount} />
            </View>

            {/* Rating */}
            <SkeletonBox style={styles.rating} />

            {/* Title */}
            <SkeletonBox style={styles.title} />

            {/* Location */}
            <SkeletonBox style={styles.location} />

            {/* Price */}
            <SkeletonBox style={styles.price} />

            {/* Button */}
            <SkeletonBox style={styles.button} />
        </View>
    );
};

const HotelListingSkeleton = () => {
    return (
        <View style={styles.container}>

            {[1, 2, 3].map((_, index) => (
                <HotelCardSkeleton key={index} />
            ))}
        </View>
    );
};

export default HotelListingSkeleton;



const styles = StyleSheet.create({
    skeleton: {
        backgroundColor: "#E1E9EE",
        overflow: "hidden",
    },
    shimmer: {
        position: "absolute",
        width: "50%",
        height: "100%",
        backgroundColor: "rgba(255,255,255,0.4)",
    },
    search: {
        height: 45,
        borderRadius: 10,
        marginBottom: 16,
    },
    card: {
        backgroundColor: "#fff",
        borderRadius: 14,
        padding: 12,
        marginBottom: 20,
    },
    image: {
        height: 180,
        borderRadius: 12,
    },
    tagRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 10,
    },
    tag: {
        height: 22,
        width: 70,
        borderRadius: 6,
    },
    discount: {
        height: 22,
        width: 120,
        borderRadius: 6,
    },
    rating: {
        height: 16,
        width: 60,
        borderRadius: 4,
        marginTop: 10,
    },
    title: {
        height: 18,
        width: "80%",
        borderRadius: 4,
        marginTop: 8,
    },
    location: {
        height: 14,
        width: "60%",
        borderRadius: 4,
        marginTop: 6,
    },
    price: {
        height: 18,
        width: "40%",
        borderRadius: 4,
        marginTop: 10,
    },
    button: {
        height: 45,
        borderRadius: 10,
        marginTop: 14,
    },
});