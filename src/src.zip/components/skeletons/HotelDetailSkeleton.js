import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";

const { width } = Dimensions.get("window");

const SkeletonBox = ({ width = "100%", height = 14, style }) => (
  <View style={[styles.box, { width, height }, style]} />
);

export default function HotelDetailSkeleton() {
  return (
    <View style={styles.container}>

      {/* Image Slider Skeleton */}
      <SkeletonBox height={360} style={styles.slider} />

      <View style={styles.content}>

        {/* Hotel Name */}
        <SkeletonBox height={20} width="80%" />
        <SkeletonBox height={14} width="55%" style={{ marginTop: 8 }} />

        {/* Rating + badges */}
        <View style={styles.row}>
          <SkeletonBox width={60} height={14} />
          <SkeletonBox width={90} height={14} />
          <SkeletonBox width={110} height={14} />
        </View>

        {/* Price */}
        <View style={styles.priceRow}>
          <SkeletonBox width={100} height={18} />
          <SkeletonBox width={70} height={16} />
        </View>

        {/* Time Slots */}
        <View style={styles.timeRow}>
          <SkeletonBox width="30%" height={50} />
          <SkeletonBox width="30%" height={50} />
          <SkeletonBox width="30%" height={50} />
        </View>

        {/* Amenities */}
        <SkeletonBox width="40%" height={16} style={{ marginTop: 20 }} />
        <View style={styles.amenitiesRow}>
          {[1, 2, 3, 4].map((i) => (
            <SkeletonBox key={i} width="22%" height={40} />
          ))}
        </View>

        {/* Policy */}
        <SkeletonBox width="35%" height={16} style={{ marginTop: 20 }} />
        <SkeletonBox height={60} style={{ marginTop: 8 }} />

      </View>

      {/* Bottom Button */}
      <View style={styles.bottom}>
        <SkeletonBox height={52} />
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  box: {
    backgroundColor: "#E1E9EE",
    borderRadius: 8,
  },
  slider: {
    width,
  },
  content: {
    padding: 16,
  },
  row: {
    flexDirection: "row",
    gap: 10,
    marginTop: 12,
  },
  priceRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 16,
  },
  timeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  amenitiesRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  bottom: {
    padding: 16,
    borderTopWidth: 1,
    borderColor: "#eee",
  },
});
