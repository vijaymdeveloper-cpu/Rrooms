import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const authSlice = createSlice({
    name: "auth",
    initialState: {
        access_token: null,
        userDetail: {},
        agreementDetail: [],
    },
    reducers: {
        saveToken: (state, {payload})=>{
            state.access_token = payload
        },
        saveUserData: (state, { payload }) => {
            state.userDetail = payload;
        },
        saveAgreementDetail: (state, {payload})=>{
            state.agreementDetail = payload
        }
    }
});

export const { saveToken, saveUserData, saveAgreementDetail } = authSlice.actions;

export default authSlice.reducer;