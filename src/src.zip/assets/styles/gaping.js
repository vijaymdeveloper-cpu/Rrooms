import { StyleSheet } from "react-native";

export const gapingStyles = StyleSheet.create({
    mt_1: {
        marginTop: 10
    }
})