import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AppLayout from "@components/AppLayout";
import Tabs from './Tabs';

import SplashScreen from '../screens/splash';
import LoginScreen from '../screens/auth';
import SignupScreen from '../screens/auth/SignupScreen';
import OtpScreen from '../screens/auth/OtpScreen';
import HotelsScreen from '../screens/hotels';
import HotelDetailsScreen from '../screens/hotelDetails';
import SearchScreen from '../screens/search';
import BookHotelScreen from '../screens/bookHotel';
import BookingConfirmedScreen from '../screens/bookingConfirmed';
import EditAccountScreen from '../screens/account/EditAccountScreen';

const Stack = createNativeStackNavigator();

const TransparentTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: 'transparent',
  },
};

export default function AppNavigator() {
  return (
    <NavigationContainer theme={TransparentTheme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignupScreen} />
        <Stack.Screen name="Otp" component={OtpScreen} />
        <Stack.Screen name="Hotels">
          {(props) => (
            <AppLayout background={{ backgroundColor: "#ebebebff" }}>
              <HotelsScreen {...props} />
            </AppLayout>
          )}
        </Stack.Screen>
        <Stack.Screen name="HotelDetails" component={HotelDetailsScreen} />
        <Stack.Screen name="BookHotel">
          {(props) => (
            <AppLayout>
              <BookHotelScreen {...props} />
            </AppLayout>
          )}
        </Stack.Screen>
        <Stack.Screen name="BookingConfirmed">
          {(props) => (
            <AppLayout background={{ backgroundColor: "#2E7D32" }} statusBarColor='light-content'>
              <BookingConfirmedScreen {...props} />
            </AppLayout>
          )}
        </Stack.Screen>
        <Stack.Screen name="Search" component={SearchScreen} />
        <Stack.Screen name="EditAccount">
          {(props) => (
            <AppLayout
              background={{ backgroundColor: "#fff" }}>
              <EditAccountScreen {...props} />
            </AppLayout>
          )}
        </Stack.Screen>


        <Stack.Screen name="Tabs" component={Tabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
