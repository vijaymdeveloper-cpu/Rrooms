import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

import HomeScreen from '../screens/home';
import BookingScreen from '../screens/bookings';
import DealScreen from '../screens/deals';
import AccountScreen from '../screens/account';

import AppLayout from "@components/AppLayout";

const Tab = createBottomTabNavigator();

export default function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,

        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          }
          else if (route.name === 'Bookings') {
            iconName = focused ? 'bag' : 'bag-outline';
          }
          else if (route.name === 'Deals') {
            iconName = focused ? 'pricetags' : 'pricetags-outline';
          }
          else if (route.name === 'Account') {
            iconName = focused ? 'person' : 'person-outline';
          }

          return <Ionicons name={iconName} size={22} color={color} />;
        },

        tabBarActiveTintColor: '#ff9d25',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: {
          height: 80,
          paddingTop: 5,
          paddingBottom: 12,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          paddingTop: 2
        }
      })}
    >
      <Tab.Screen name="Home">
        {(props) => (
          <AppLayout
            background={require("@assets/images/bg58.jpg")}
            // background={{ backgroundColor: "#e5e8f7ff" }}
          >
            <HomeScreen {...props} />
          </AppLayout>
        )}
      </Tab.Screen>

      <Tab.Screen name="Bookings">
        {(props) => (
          <AppLayout background={{ backgroundColor: "#f5f6fa" }}>
            <BookingScreen {...props} />
          </AppLayout>
        )}
      </Tab.Screen>

      <Tab.Screen name="Deals" component={DealScreen} />

      <Tab.Screen name="Account">
        {(props) => (
          <AppLayout
            background={{ backgroundColor: "#f5f6fa" }}>
            <AccountScreen {...props} />
          </AppLayout>
        )}
      </Tab.Screen>

    </Tab.Navigator>
  );
}
