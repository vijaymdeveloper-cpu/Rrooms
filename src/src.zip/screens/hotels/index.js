import { View, FlatList, Text } from "react-native";

import useHotelsController from "@controllers/hotelsController";
import { commonStyles } from '@assets/styles/commonStyles'
import Header from '@components/Header'
import SearchBox from '@components/SearchBox'
import HotelCard from "./HotelCard";
import HotelListingSkeleton from '@components/skeletons/HotelListingSkeleton'

export default function HotelsScreen({ navigation }) {

  const {
    loading,
    properties,
    count,
    getAverageRating,
    mergeAllSlotsForDate,
    safeParse
  } = useHotelsController();

  return (
    <View style={commonStyles.screenWrapper}>
      <Header showBack={true} />
      <View style={commonStyles.mb_2}>
        <SearchBox height={52} />
      </View>
      <Text style={commonStyles.mb_2}>
        {
          loading ? "We are finding amazing hotels for you..."
            : <>
              We found <Text style={commonStyles.fwBold}>{count}</Text> amazing ROOMS hotels for you
            </>
        }
      </Text>

      {
        loading ? <HotelListingSkeleton /> : (
          <FlatList
            data={properties}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <HotelCard
                item={item}
                getAverageRating={getAverageRating}
                mergeAllSlotsForDate={mergeAllSlotsForDate}
                safeParse={safeParse}
                commonStyles={commonStyles}
                navigation={navigation}
              />
            )}
            showsVerticalScrollIndicator={false}
          />
        )
      }
    </View>
  );
}

