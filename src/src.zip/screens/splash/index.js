import React, { useEffect } from "react";
import { View, Image, Text, StyleSheet, ImageBackground } from "react-native";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { commonStyles } from '@assets/styles/commonStyles'
import { useSelector } from "react-redux";

export default function SplashScreen() {

    const navigation = useNavigation();
    const { access_token } = useSelector((state)=> state.auth)

    useEffect(() => {
        const checkAuth = async () => {
            await new Promise(res => setTimeout(res, 1500));

            const token = access_token;

            if (token) {
                navigation.replace("Tabs");
            } else {
                navigation.replace("Login");
            }
        };

        checkAuth();
    }, []);

    return (
        <ImageBackground
            source={require("@assets/images/bg-splash.jpeg")}
            style={styles.bg}
            resizeMode="cover"
        >
            <View style={styles.logoWrapper}>
                <Image
                    source={require('../../assets/images/logo.png')}
                    style={styles.logo}
                />
            </View>

            <Text style={[commonStyles.textLogo, { fontSize: 52 }]}>
                <Text style={{ color: '#ff9d25' }}>R</Text>ROOMS
            </Text>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    bg: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#fff",
    },
    logoWrapper: {
        width: 120,
        borderWidth: 2,
        borderColor: '#3C4043',
        borderRadius: 10,
        alignItems: 'center',
        padding: 20,
        marginBottom: 10
    },
    logo: {
        width: 60,
        height: 80,

    },
});
