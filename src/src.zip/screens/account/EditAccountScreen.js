import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
} from "react-native";
import { useForm, Controller } from "react-hook-form";
import { commonStyles } from "@assets/styles/commonStyles";
import Ionicons from "react-native-vector-icons/Ionicons";
import services from "@api/services";

const EditAccountScreen = ({ navigation, route }) => {

  const { userData, baseImgUrl } = route.params || {};

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: userData?.name || "",
      email: userData?.email || "",
    },
  });

  const saveEditHandler = async (payload) => {
    try {
      const formData = new FormData();
      formData.append("name", payload.name ?? "");
      formData.append("email", payload.email ?? "");
      // formData.append("profileImage", payload.img || baseImgUrl);
      // formData.append("address", payload.address || userData.address);
      // formData.append("company", payload.company || userData.company);
      // formData.append("gst", payload.gst || userData.gst);
      const res = await services.editCustomerService(userData?.id, formData);
      // console.log('res', res)
      if (res.status === 200) {

      }
    } catch (error) { }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color="#000" />
        </TouchableOpacity>

        <Text style={styles.headerTitle}>Edit Profile</Text>

        <TouchableOpacity onPress={handleSubmit(saveEditHandler)}>
          <Ionicons name="checkmark" size={24} color="#2E7D32" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Image */}
        <View style={styles.imageWrapper}>
          <Image
            source={{ uri: `${baseImgUrl}${userData?.profileImage}` || "https://i.pravatar.cc/300" }}
            style={styles.profileImage}
          />
          <TouchableOpacity style={styles.cameraIcon}>
            <Ionicons name="camera-outline" size={16} color="#000" />
          </TouchableOpacity>
        </View>

        {/* Form */}
        <View style={styles.form}>

          {/* Name */}
          <View style={commonStyles.formGroup}>
            <Text style={commonStyles.label}>Name</Text>
            <Controller
              control={control}
              name="name"
              rules={{ required: "Name is required" }}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  style={commonStyles.input2}
                  value={value}
                  onChangeText={onChange}
                  placeholder="Enter name"
                />
              )}
            />
            {errors.name && <Text style={styles.error}>{errors.name.message}</Text>}
          </View>

          {/* Email */}
          <View style={commonStyles.formGroup}>
            <Text style={commonStyles.label}>Email address</Text>
            <Controller
              control={control}
              name="email"
              rules={{
                required: "Email is required",
                pattern: {
                  value: /^\S+@\S+$/i,
                  message: "Invalid email",
                },
              }}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  style={commonStyles.input2}
                  value={value}
                  onChangeText={onChange}
                  placeholder="Email"
                  keyboardType="email-address"
                />
              )}
            />
            {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}
          </View>

          {/* Save Button */}
          <View style={[commonStyles.formGroup, commonStyles.mt_2]}>
            <TouchableOpacity
              style={[commonStyles.btn, commonStyles.btnPrimary]}
              onPress={handleSubmit(saveEditHandler)}
            >
              <Text style={commonStyles.btnText}>Save Profile</Text>
            </TouchableOpacity>
          </View>

        </View>
      </ScrollView>
    </View>
  );
};

export default EditAccountScreen;




const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: "#fff",
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
  },

  headerTitle: {
    fontSize: 18,
    fontWeight: "600",
  },

  imageWrapper: {
    alignItems: "center",
    marginVertical: 10,
  },

  profileImage: {
    width: 96,
    height: 96,
    borderRadius: 48,
  },

  cameraIcon: {
    position: "absolute",
    bottom: 0,
    right: "38%",
    backgroundColor: "#fff",
    padding: 6,
    borderRadius: 20,
    elevation: 4,
  },
  form: {
    paddingHorizontal: 20,
  },
  passwordInput: {
    fontSize: 14,
    flex: 1,
  },
});
