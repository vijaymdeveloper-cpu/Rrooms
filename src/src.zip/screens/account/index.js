import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { baseImgUrl } from '@api/client'
import { saveUserData } from '@store/slices/authSlice'
import Ionicons from "react-native-vector-icons/Ionicons";
import services from "@api/services";

const MENU_ITEMS = [
  // { title: "Account Details", icon: "person-outline" },
  { title: "Wallet Balance", icon: "wallet-outline" },
  { title: "Privacy Policy", icon: "shield-checkmark-outline" },
  { title: "Help & Support", icon: "help-circle-outline" },
  { title: "FAQs", icon: "chatbubble-ellipses-outline" },
  { title: "About Us", icon: "information-circle-outline" },
  { title: "Terms & Condition", icon: "document-text-outline" },
  { title: "Refer & Earn", icon: "gift-outline" },
  { title: "Log out", icon: "log-out-outline", danger: true },
];


const MyProfileScreen = ({ navigation }) => {

  const [userData, setUserData] = useState({})
  const [imgFile, setImgFile] = useState(null);

  const dispatch = useDispatch();
  const { userDetail } = useSelector((state) => state.auth)

  const fetchUserData = async () => {
    try {
      const res = await services.getCustomerProfileService(userDetail?.id);
      if (res.status === 200) {
        setUserData(res?.data?.data);
        setImgFile(res?.data?.data?.profileImage);
        dispatch(saveUserData(res.data.data))
      }
    } catch (error) { }
  };

  useEffect(() => {
    if (userDetail?.id) {
      fetchUserData()
    }
  }, []);

  return (
    <View style={styles.container}>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.profileSection}>
          <View>
            <Image
              source={{ uri: `${baseImgUrl}${imgFile}` }}
              style={styles.profileImage}
            />
          </View>

          <Text style={styles.name}>{userData?.name}</Text>
          <Text style={styles.username}>{userData?.email}</Text>

          <TouchableOpacity style={styles.editBtn} onPress={() => navigation.navigate('EditAccount', {userData, baseImgUrl})}>
            <Text style={styles.editText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>

        <View style={{ paddingHorizontal: 20 }}>
          <View style={styles.menuCard}>
            {MENU_ITEMS.map((item, index) => (
              <TouchableOpacity key={index} style={styles.menuItem}>
                <View style={styles.menuLeft}>
                  <Ionicons
                    name={item.icon}
                    size={20}
                    color={item.danger ? "#E53935" : "#000"}
                  />
                  <Text
                    style={[
                      styles.menuText,
                      item.danger && { color: "#E53935" }
                    ]}
                  >
                    {item.title}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#999" />
              </TouchableOpacity>
            ))}
          </View>
        </View>

      </ScrollView>
    </View>
  );
};

export default MyProfileScreen;

const styles = StyleSheet.create({
  headerWrapper: {
    paddingHorizontal: 20,
    marginBottom: 10
  },
  profileSection: {
    alignItems: "center",
    marginTop: 20
  },
  profileImage: {
    width: 90,
    height: 90,
    borderRadius: 45,
  },

  name: {
    fontSize: 18,
    fontWeight: "600",
    marginTop: 12,
  },

  username: {
    fontSize: 14,
    color: "#777",
    marginTop: 2,
  },

  editBtn: {
    backgroundColor: "#EF4444",
    paddingHorizontal: 28,
    paddingVertical: 10,
    borderRadius: 22,
    marginTop: 14,
  },

  editText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "500",
  },

  menuCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    marginTop: 24,
  },

  menuItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 0.6,
    borderColor: "rgba(0, 0, 0, 0.1)",
  },

  menuLeft: {
    flexDirection: "row",
    alignItems: "center",
  },

  menuText: {
    fontSize: 15,
    marginLeft: 14,
  },
});
