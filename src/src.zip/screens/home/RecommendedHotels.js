import React from "react";
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { baseImgUrl } from "@api/client";

const RecommendedHotels = ({
    data = [],
    onViewAll,
    commonStyles,
}) => {
    // console.log('properties', properties)
    return (
        <View style={commonStyles.mt_2}>
            <View style={[commonStyles.rowBetween, commonStyles.mb_3]}>
                <Text style={commonStyles.text_4}>{'Recommended For You'}</Text>

                {/* <TouchableOpacity onPress={onViewAll}>
                    <Text style={commonStyles.btnLink}>View All</Text>
                </TouchableOpacity> */}
            </View>
            <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.scrollContainer}
            >
                {data?.map((item, index) => (
                    <View key={index} style={styles.itemCard}>
                        <Image
                            source={{ uri: baseImgUrl+item?.PropertyImages[0]?.image }}
                            style={styles.itemCardImage}
                        />

                        <View style={{ padding: 10 }}>
                            <Text style={[commonStyles.text_5]}>
                                {item?.locality}, {item?.city?.name}
                            </Text>

                            <Text style={styles.itemLocation}>
                                {item?.locality}
                            </Text>

                        </View>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

export default RecommendedHotels;

const styles = StyleSheet.create({
    itemCard: {
        width: 180,
        backgroundColor: "#fff",
        borderRadius: 14,
        overflow: 'hidden',
        marginRight: 14
    },
    itemCardImage: {
        width: '100%',
        height: 120
    },
    itemLocation: {
        fontSize: 12,
        color: '#666',
        marginVertical: 2,
    },
    itemPrice: {
        fontSize: 14,
        // fontWeight: 'bold'
    },
})
