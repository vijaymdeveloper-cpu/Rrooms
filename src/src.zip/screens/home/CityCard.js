import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

const CityCard = ({ title, image, isNearby = false, onPress }) => {
    return (
        <TouchableOpacity style={styles.cityCard} onPress={onPress}>
            {isNearby ? (
                <View style={styles.iconLocation}>
                    <Icon name="navigate" size={34} color="#fff" />
                </View>
            ) : (
                <Image source={{ uri: image }} style={styles.cityImage} />
            )}

            <Text style={styles.cityName}>{title}</Text>
        </TouchableOpacity>
    );
};

export default CityCard;

const styles = StyleSheet.create({
    cityCard: {
        alignItems: 'center',
        marginRight: 14
    },
    iconLocation: {
        width: 72,
        height: 72,
        backgroundColor: '#456efe',
        borderRadius: 100,
        justifyContent: 'center',
        alignItems: 'center',
    },
    cityImage: {
        width: 72,
        height: 72,
        borderRadius: 100,
    },
    cityName: {
        fontSize: 14,
        fontWeight: "400",
        textAlign: 'center',
        marginTop: 6,
    },
})