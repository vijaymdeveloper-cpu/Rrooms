import React from "react";
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from "react-native";
import { TRAVEL_OPTIONS } from "@constants";

const TravelerChoice = ({ commonStyles, onViewAll, handleFilterByTravelChoise }) => {
  return (
    <View style={[commonStyles.mt_6, commonStyles.mb_4]}>
      <View style={[commonStyles.rowBetween, commonStyles.mb_4]}>
        <Text style={commonStyles.text_4}>Explore by Traveler’s choice</Text>
        <TouchableOpacity onPress={onViewAll}>
          <Text style={commonStyles.btnLink}>View All</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {TRAVEL_OPTIONS?.map((item, index) => (
          <TouchableOpacity key={index} style={styles.card} onPress={()=> handleFilterByTravelChoise(item)}>
            <Image source={{ uri: item?.img }} style={styles.cardImage} />

            <View style={styles.cardTextContainer}>
              <Text style={styles.cardTitle}>{item?.title}</Text>
              <Text style={styles.cardSubtitle}>{item?.subtitle}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

export default TravelerChoice;


const styles = StyleSheet.create({
  card: {
    width: 245,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#fff",
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    marginRight: 14
  },
  cardImage: {
    width: "100%",
    height: 150,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
    position: "absolute",
    bottom: 35,
    left: 10,
    paddingHorizontal: 5,
    borderRadius: 5,
  },
  cardSubtitle: {
    fontSize: 12,
    color: "#fff",
    position: "absolute",
    bottom: 10,
    left: 10,
    paddingHorizontal: 5,
    borderRadius: 5,
  },
})