import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from "react-native";
import useHomeController from "@controllers/homeController";
import { commonStyles } from '@assets/styles/commonStyles'
import { mainUrl } from '@api/client';
import Header from '@components/Header'
import SearchBox from '@components/SearchBox';
import TravelerChoice from './TravelerChoice';
import CityCard from './CityCard';
import RecommendedHotels from './RecommendedHotels';

const HomeScreen = ({ navigation }) => {

  const {
    filterCities,
    properties,
    handleCityPress,
    handleNearByPress,
    handleFilterByTravelChoise
  } = useHomeController();

  return (
    <View style={commonStyles.screenWrapper}>
      <Header />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.heroText]}>
          <Text style={commonStyles.text_1}>Let’s Find The Best Hotel</Text>
          <Text style={[commonStyles.text_5, commonStyles.text_light, commonStyles.mt_1]}>
            Book budget, premium, and luxury stays.
          </Text>
        </View>
        <SearchBox />
        <View style={[commonStyles.mt_5, commonStyles.mb_5]}>
          <Text style={[commonStyles.text_4, commonStyles.mb_3]}>
            Explore By Cities
          </Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.scrollContainer}
          >
            <CityCard
              title="Near By"
              isNearby
              styles={styles}
              onPress={handleNearByPress}
            />

            {filterCities?.map((item) => {
              const img = `${mainUrl}${item.city_img}`;
              return (
                <CityCard
                  key={item.id}
                  title={item?.name}
                  image={img}
                  styles={styles}
                  onPress={() => handleCityPress(item)}
                />
              );
            })}
          </ScrollView>
        </View>
        <RecommendedHotels
          commonStyles={commonStyles}
          styles={styles}
          data={properties}
          // onViewAll={() => navigation.navigate("Hotels")}
        />
        <TravelerChoice
          commonStyles={commonStyles}
          onViewAll={() => navigation.navigate("HotelDetails")}
          handleFilterByTravelChoise={handleFilterByTravelChoise}
        />
        <View style={styles.offerBox}>
          <View>
            <Image style={styles.offerImg} source={require('@assets/images/img-offer.png')} />
            <View style={styles.offerContent}>
              <Text style={[commonStyles.text_3, commonStyles.textWhite]}>Don’t think</Text>
              <Text style={styles.offerSubTitle}>Book in blink!</Text>
              <TouchableOpacity style={[commonStyles.btn, commonStyles.btnSecondary, commonStyles.btnFullWidth]}>
                  <Text style={commonStyles.btnText}>Book Now</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  heroText: {
    alignItems: 'center',
    paddingTop: 35,
    paddingBottom: 25
  },
  offerBox: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 30,
    marginTop: 5
  },
  offerImg: {
    width: '100%',
  },
  offerContent: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 20
    // backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },
  offerSubTitle: {
    backgroundColor: '#FF9D25',
    color: '#3C4043',
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 6,
    marginTop: 10,
    marginBottom: 20
  }
});
