import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";

const BookingScreen = () => {
  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Single Booking Tile */}
        <View style={styles.mainCard}>

          {/* Status */}
          <View style={styles.statusRow}>
            <Ionicons name="checkmark-circle" size={16} color="#2ecc71" />
            <Text style={styles.statusText}>Checked-In</Text>
          </View>

          {/* Image */}
          <Image
            source={{ uri: "https://rrooms.in/rrooms/uploads/Facade-1740986668473.PNG" }}
            style={styles.hotelImage}
          />

          {/* Hotel Info */}
          <Text style={styles.hotelName}>RROOMS Elite Hotel Rrooms</Text>
          <Text style={styles.address}>
            Plot No-297, Kanpur-Lucknow Rd, Lucknow
          </Text>

          {/* Dates */}
          <View style={styles.dateRow}>
            <DateItem label="Check-In" value="26 May 2025" />
            <DateItem label="Check-Out" value="28 May 2025" />
            <DateItem label="Nights" value="2" />
          </View>

          {/* Divider */}
          <View style={styles.divider} />

          {/* Booking Details */}
          <DetailRow label="Booking ID" value="RRP813343" />
          <DetailRow label="Adults" value="1" />
          <DetailRow label="Children" value="0" />
          <DetailRow label="Room Type" value="EP | Standard Double Bed" />

          <View style={styles.divider} />

          {/* Payment */}
          <DetailRow label="Discount" value="₹ 0" />
          <DetailRow label="Total Amount" value="₹ 1904" bold />

          <Text style={styles.paidText}>Fully Paid</Text>

          {/* Actions */}
          <View style={styles.actionRow}>
            <TouchableOpacity style={styles.helpBtn}>
              <Text style={styles.helpText}>Need Help?</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.primaryBtn}>
              <Ionicons name="restaurant" size={16} color="#fff" />
              <Text style={styles.primaryText}>Order Food</Text>
            </TouchableOpacity>
          </View>

        </View>

      </ScrollView>
    </View>
  );
};

const DateItem = ({ label, value }) => (
  <View style={styles.dateItem}>
    <Text style={styles.label}>{label}</Text>
    <Text style={styles.value}>{value}</Text>
  </View>
);

const DetailRow = ({ label, value, bold }) => (
  <View style={styles.detailRow}>
    <Text style={styles.label}>{label}</Text>
    <Text style={[styles.value, bold && styles.bold]}>{value}</Text>
  </View>
);

export default BookingScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f6fa"
  },

  mainCard: {
    backgroundColor: "#fff",
    margin: 16,
    padding: 16,
    borderRadius: 16
  },

  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10
  },
  statusText: {
    marginLeft: 6,
    color: "#2ecc71",
    fontWeight: "600"
  },

  hotelImage: {
    width: "100%",
    height: 120,   // compact
    borderRadius: 12,
    marginBottom: 12
  },

  hotelName: {
    fontSize: 17,
    fontWeight: "700",
    color: "#111"
  },
  address: {
    marginTop: 4,
    color: "#777",
    fontSize: 13
  },

  dateRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14
  },
  dateItem: {
    alignItems: "center",
    flex: 1
  },

  divider: {
    height: 1,
    backgroundColor: "#eee",
    marginVertical: 14
  },

  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 4
  },

  label: {
    color: "#888",
    fontSize: 13
  },
  value: {
    color: "#111",
    fontSize: 13
  },
  bold: {
    fontWeight: "700"
  },

  paidText: {
    marginTop: 8,
    color: "#27ae60",
    fontWeight: "700",
    textAlign: "right"
  },

  actionRow: {
    flexDirection: "row",
    marginTop: 16
  },

  helpBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
    height: 42
  },
  helpText: {
    fontWeight: "600",
    color: "#333"
  },

  primaryBtn: {
    flex: 1,
    backgroundColor: "#1e90ff",
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 42
  },
  primaryText: {
    color: "#fff",
    fontWeight: "700",
    marginLeft: 6
  }
});
