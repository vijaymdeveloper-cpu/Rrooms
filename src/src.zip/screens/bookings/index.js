import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import Header from '@components/Header'
import { commonStyles } from '@assets/styles/commonStyles'

const BookingScreen = () => {

  const [activeTab, setActiveTab] = useState("upcoming");

  return (
    <View style={commonStyles.screenWrapper}>
      <Header />

      <View style={styles.tabWrapper}>
        <View style={styles.tabContainer}>
          <TabButton
            title="Upcoming"
            active={activeTab === "upcoming"}
            onPress={() => setActiveTab("upcoming")}
          />
          <TabButton
            title="Previous"
            active={activeTab === "previous"}
            onPress={() => setActiveTab("previous")}
          />
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.card}>

          <View>
            <View style={[styles.statusPill, commonStyles.row]}>
              <Ionicons name="checkmark-circle" size={14} color="#27ae60" />
              <Text style={styles.statusText}>Checked-In</Text>
            </View>
            <Text style={[styles.hotelName, commonStyles.text_3]}>RROOMS Elite Hotel Rrooms</Text>
            <Text style={styles.address}>
              Plot No-297, Kanpur-Lucknow Rd, Lucknow
            </Text>
          </View>

          {/* Image */}
          <Image
            source={{ uri: "https://rrooms.in/rrooms/uploads/Facade-1740986668473.PNG" }}
            style={styles.image}
          />

          {/* Dates */}
          <View style={[styles.dateRow, commonStyles.row, commonStyles.itemsCenter]}>
            <DateBlock title="Check-In" value="26 May" />
            <View style={styles.dateDivider} />
            <DateBlock title="Check-Out" value="28 May" />
            <View style={styles.dateDivider} />
            <DateBlock title="Nights" value="2" />
          </View>

          {/* Details */}
          <InfoRow label="Booking ID" value="RRP813343" />
          <InfoRow label="Guests" value="1 Adult • 0 Child" />
          <InfoRow label="Room Type" value="EP | Standard Double Bed" />

          {/* Payment */}
          <View style={styles.paymentBox}>
            <InfoRow label="Total Amount" value="₹ 1904" bold />
            <Text style={styles.paidText}>Fully Paid</Text>
          </View>

          {/* Actions */}
          <View style={[commonStyles.row, commonStyles.mt_3]}>
            <TouchableOpacity style={[commonStyles.btnOutline, commonStyles.btnOutlineDark, commonStyles.mr_2, { flex: 1 }]}>
              <Text style={commonStyles.btnOutlineDarkText}>Need Help</Text>
            </TouchableOpacity>

            <TouchableOpacity style={[commonStyles.btn, commonStyles.btnPrimary, commonStyles.row]}>
              <Ionicons name="restaurant" size={16} color="#fff" />
              <Text style={[commonStyles.btnText, { marginLeft: 6 }]}>Order Food</Text>
            </TouchableOpacity>
          </View>

        </View>
      </ScrollView>
    </View>
  );
};

/* ---------- Small Components ---------- */

const DateBlock = ({ title, value }) => (
  <View style={styles.dateBlock}>
    <Text style={styles.dateTitle}>{title}</Text>
    <Text style={styles.dateValue}>{value}</Text>
  </View>
);

const InfoRow = ({ label, value, bold }) => (
  <View style={[commonStyles.rowBetween, styles.infoRow]}>
    <Text style={styles.infoLabel}>{label}</Text>
    <Text style={[styles.infoValue, bold && styles.bold]}>{value}</Text>
  </View>
);

const TabButton = ({ title, active, onPress }) => (
  <TouchableOpacity
    onPress={onPress}
    style={[styles.tabBtn, active && styles.activeTab]}
  >
    <Text style={[styles.tabText, active && styles.activeTabText]}>
      {title}
    </Text>
  </TouchableOpacity>
);

export default BookingScreen;


const styles = StyleSheet.create({
  tabWrapper: {
    flexDirection: 'row',
    justifyContent: 'center'
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderRadius: 30,
    overflow: 'hidden',
    padding: 0,
    margin: 16,
  },
  tabBtn: {
    width: 120,
    paddingVertical: 12,
    alignItems: "center"
  },
  tabText: {
    color: "#777"
  },
  activeTab: {
    backgroundColor: "#1e90ff"
  },
  activeTabText: {
    fontWeight: "600",
    color: "#fff"
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 16,
  },
  hotelName: {
    color: "#111",
    marginBottom: 3
  },
  statusPill: {
    width: 120,
    backgroundColor: "#eafaf1",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    marginBottom: 10
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#27ae60",
    marginLeft: 4,
  },
  address: {
    color: "#777",
    fontSize: 12
  },
  image: {
    width: "100%",
    height: 110,
    borderRadius: 14,
    marginTop: 14,
    marginBottom: 14
  },
  dateRow: {
    backgroundColor: "#fff7e6",
    borderRadius: 12,
    paddingVertical: 10,
    marginBottom: 14
  },
  dateBlock: {
    flex: 1,
    alignItems: "center"
  },
  dateTitle: {
    fontSize: 12,
    color: "#888"
  },
  dateValue: {
    fontSize: 14,
    fontWeight: "700",
    marginTop: 2
  },
  dateDivider: {
    width: 1,
    height: 30,
    backgroundColor: "#f7dfabff"
  },
  infoRow: {
    marginVertical: 4
  },
  infoLabel: {
    color: "#888",
    fontSize: 12
  },
  infoValue: {
    color: "#111",
    fontSize: 13
  },
  bold: {
    fontWeight: "700"
  },
  paymentBox: {
    borderTopWidth: 1,
    borderColor: "#eee",
    paddingTop: 10,
    marginTop: 12,
  },
  paidText: {
    textAlign: "right",
    color: "#27ae60",
    fontWeight: "700",
    fontSize: 14,
    marginTop: 6,
  },
});
