import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";

const BookingScreen = () => {
  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Status */}
        <View style={styles.statusBadge}>
          <Ionicons name="checkmark-circle" size={16} color="#2ecc71" />
          <Text style={styles.statusText}>Checked-In</Text>
        </View>

        {/* Hotel Image (Compact Card) */}
        <View style={styles.imageCard}>
          <Image
            source={{ uri: "https://rrooms.in/rrooms/uploads/Facade-1740986668473.PNG" }}
            style={styles.hotelImage}
          />
        </View>

        {/* Hotel Info */}
        <View style={styles.card}>
          <Text style={styles.hotelName}>RROOMS Elite Hotel Rrooms</Text>
          <Text style={styles.address}>
            Plot No-297, Kanpur-Lucknow Rd, Lucknow
          </Text>
        </View>

        {/* Dates */}
        <View style={styles.rowCard}>
          <View style={styles.dateItem}>
            <Text style={styles.label}>Check-In</Text>
            <Text style={styles.value}>26 May 2025</Text>
          </View>
          <View style={styles.dateItem}>
            <Text style={styles.label}>Check-Out</Text>
            <Text style={styles.value}>28 May 2025</Text>
          </View>
          <View style={styles.dateItem}>
            <Text style={styles.label}>Nights</Text>
            <Text style={styles.value}>2</Text>
          </View>
        </View>

        {/* Booking Details */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Booking Details</Text>

          <DetailRow label="Booking ID" value="RRP813343" />
          <DetailRow label="Adults" value="1" />
          <DetailRow label="Children" value="0" />
          <DetailRow label="Room Type" value="EP | Standard Double Bed" />
        </View>

        {/* Payment */}
        <View style={styles.paymentCard}>
          <Text style={styles.sectionTitle}>Payment Summary</Text>

          <DetailRow label="Discount" value="₹ 0" />
          <DetailRow label="Total Amount" value="₹ 1904" bold />

          <Text style={styles.paidText}>Fully Paid</Text>
        </View>

      </ScrollView>

      {/* Bottom Actions */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.helpBtn}>
          <Text style={styles.helpText}>Need Help?</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.primaryBtn}>
          <Ionicons name="restaurant" size={18} color="#fff" />
          <Text style={styles.primaryText}>Order Food</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const DetailRow = ({ label, value, bold }) => (
  <View style={styles.detailRow}>
    <Text style={styles.label}>{label}</Text>
    <Text style={[styles.value, bold && styles.boldText]}>{value}</Text>
  </View>
);

export default BookingScreen;


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f6fa"
  },

  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#eafaf1",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    margin: 16
  },
  statusText: {
    marginLeft: 6,
    color: "#2ecc71",
    fontWeight: "600"
  },

  imageCard: {
    marginHorizontal: 16,
    marginTop: 4,
    borderRadius: 14,
    overflow: "hidden",
    backgroundColor: "#fff"
  },

  hotelImage: {
    width: "100%",
    height: 120,   // ✅ compact height
    resizeMode: "cover"
  },

  card: {
    backgroundColor: "#fff",
    margin: 16,
    padding: 16,
    borderRadius: 14
  },

  rowCard: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    padding: 16,
    borderRadius: 14,
    flexDirection: "row",
    justifyContent: "space-between"
  },

  dateItem: {
    alignItems: "center",
    flex: 1
  },

  hotelName: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111"
  },
  address: {
    marginTop: 6,
    color: "#777"
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 12
  },

  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 6
  },

  label: {
    color: "#888"
  },
  value: {
    color: "#111"
  },

  boldText: {
    fontWeight: "700"
  },

  paymentCard: {
    backgroundColor: "#fff7e6",
    margin: 16,
    padding: 16,
    borderRadius: 14
  },

  paidText: {
    marginTop: 10,
    color: "#27ae60",
    fontWeight: "700",
    textAlign: "right"
  },

  bottomBar: {
    flexDirection: "row",
    padding: 12,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderColor: "#eee"
  },

  helpBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10
  },
  helpText: {
    color: "#333",
    fontWeight: "600"
  },

  primaryBtn: {
    flex: 1,
    backgroundColor: "#1e90ff",
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center"
  },
  primaryText: {
    color: "#fff",
    fontWeight: "700",
    marginLeft: 6
  }
});
