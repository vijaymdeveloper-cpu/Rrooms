import React, { useEffect, useState, useRef } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    FlatList,
    ScrollView,
    Dimensions,
    StatusBar,
    TouchableOpacity,
    ActivityIndicator,
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import Icon from "react-native-vector-icons/Ionicons";
import { baseImgUrl } from "@api/client";
import services from "@api/services";
import { commonStyles } from '@assets/styles/commonStyles';
import HotelDetailSkeleton from '@components/skeletons/HotelDetailSkeleton'
import NearByHotels from './NearByHotels';

const { width } = Dimensions.get("window");

const amenities = [
    { id: 1, icon: "wifi-outline", label: "Free Wi-Fi\nin all rooms" },
    { id: 2, icon: "restaurant-outline", label: "Paid\nBreakfast" },
    { id: 3, icon: "snow-outline", label: "Air\nConditioning" },
    { id: 4, icon: "car-outline", label: "Free\nParking" },
    { id: 5, icon: "tv-outline", label: "Flat-screen\nTV" },
    { id: 6, icon: "shield-checkmark-outline", label: "24×7\nSecurity" },
    { id: 7, icon: "water-outline", label: "Hot\nWater" },
    { id: 8, icon: "fitness-outline", label: "Fitness\nCenter" },
];

const rooms = [
    {
        id: '1',
        name: 'Standard Double Bed',
        price: 2200,
        originalPrice: 1374,
        discount: '16% OFF',
        image: require("@assets/images/room.jpg"),
        amenities: ['wifi', 'breakfast', 'ac'],
    },
    {
        id: '2',
        name: 'Super Deluxe Room',
        price: 2200,
        originalPrice: 1374,
        discount: '16% OFF',
        image: require("@assets/images/room2.jpg"),
        amenities: ['wifi', 'breakfast', 'ac'],
    },
];

export default function HotelDetailsScreen({ route, navigation }) {

    const { hotelId, hotelName, img } = route.params;

    const [hotelDetails, setHotelDetails] = useState({})
    const [loading, setLoading] = useState(true);
    const [showPolicy, setShowPolicy] = useState(null);
    const [plan, setPlan] = useState('Full_Day_Plan');

    const getPropertyDetail = async (id) => {
        setLoading(true)
        try {
            const res = await services.singlePropertyService(id);
            if (res.status === 200) {
                let data = res?.data?.data;
                setHotelDetails(data);
                let policy = [data.bookingPolicy];
                if (isJsonString(data.bookingPolicy)) {
                    policy = JSON.parse(data.bookingPolicy);
                }
                const cleanedArray = policy.filter(item => item.trim() !== "");
                setShowPolicy(cleanedArray);
            }
        } catch (error) { }
        finally { setLoading(false) }
    };

    useEffect(() => {
        getPropertyDetail(hotelId)
    }, [hotelId])

    const renderRoom = ({ item }) => (
        <View style={styles.card}>
            <Image source={item.image} style={styles.roomImage} />
            <Text style={styles.roomName}>{item.name}</Text>
            <View style={styles.amenitiesRow}>
                <Text style={[commonStyles.rowBetween, commonStyles.itemsCenter, styles.roomAmenityText]}>
                    <Ionicons name="wifi-outline" size={14} color="#555" />
                    Fee Internet
                </Text>
                <Text style={styles.roomAmenityText}><Ionicons name="restaurant-outline" size={14} color="#555" /> Fee Breakfast
                </Text>
                <Text style={styles.roomAmenityText}><Ionicons name="snow-outline" size={14} color="#555" /> Air conditioning</Text>
            </View>
            <Text style={styles.price}>
                ₹{item.price}/night{' '}
                <Text style={styles.originalPrice}>₹{item.originalPrice}</Text>{' '}
                <Text style={styles.discount}>{item.discount}</Text>
            </Text>
            <TouchableOpacity style={styles.bookBtn} onPress={()=> navigation.navigate('BookHotel')}>
                <Text style={styles.bookBtnText}>Book Now</Text>
            </TouchableOpacity>
        </View>
    );

    const BookingCard = ({ hours }) => {
        return (
            <View style={styles.innerCard}>
                {/* Top Row */}
                <View style={styles.topRow}>
                    <View style={styles.priceRow}>
                        <Text style={styles.price}>₹2200</Text>
                        <Text style={styles.oldPrice}>₹1374</Text>
                        <Text style={styles.off}>16% Off</Text>
                    </View>

                    <View style={{ alignItems: "flex-end" }}>
                        <Text style={styles.hours}>{hours}</Text>
                        <Text style={styles.flexible}>Flexible check in</Text>
                    </View>
                </View>

                <Text style={styles.taxText}>Incl. taxes & fees</Text>

                {/* Dropdown */}
                <TouchableOpacity style={styles.dropdown}>
                    <Text style={styles.dropdownText}>Select Check-in Time</Text>
                    <Text style={styles.arrow}>⌄</Text>
                </TouchableOpacity>

                {/* Button */}
                <TouchableOpacity style={styles.button}>
                    <Text style={styles.buttonText}>Book Now</Text>
                </TouchableOpacity>
            </View>
        );
    };

    return ( 
        <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
            <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
            {
                loading ? (
                    <HotelDetailSkeleton />
                ) :
                    <>
                        <View style={styles.imageWrapper}>
                            <FlatList
                                data={hotelDetails?.PropertyImage || []}
                                horizontal
                                pagingEnabled
                                showsHorizontalScrollIndicator={false}
                                keyExtractor={(img, index) => index.toString()}
                                renderItem={({ item: img }) => (
                                    <Image
                                        source={{ uri: baseImgUrl + img.image }}
                                        style={styles.image}
                                    />
                                )}
                            />
                            <View style={styles.topButton}>
                                <TouchableOpacity style={styles.btnCircle} onPress={() => navigation.goBack()}>
                                    <Icon name="arrow-back" size={24} color="#000" />
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.btnCircle} onPress={() => navigation.goBack()}>
                                    <Ionicons name="share-outline" size={22} color="#000" />
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View style={[commonStyles.rowCenter, { marginTop: -30 }]}>
                            {
                                hotelDetails?.PropertyImage?.slice(0, 4)?.map((item) => {
                                    return (
                                        <View style={styles.thumbBox} key={item?.id}>
                                            <Image source={{ uri: baseImgUrl + item.image }} style={styles.thumbImg} />
                                        </View>
                                    )
                                })
                            }
                        </View>

                        <View style={styles.content}>
                            <Text style={styles.title}>{hotelDetails?.name}</Text>
                            <View style={[commonStyles.row, commonStyles.itemsCenter, commonStyles.mb_3]}>
                                <Text style={styles.location}>
                                    {hotelDetails?.address}
                                </Text>
                            </View>
                            <View style={commonStyles.row}>
                                <View style={styles.featureBadge}>
                                    <Ionicons name="cash-outline" size={12} color="#fff" />
                                    <Text style={styles.featureText}> Pay at Hotels</Text>
                                </View>
                                <View style={styles.featureBadge}>
                                    <Ionicons name="heart-outline" size={12} color="#fff" />
                                    <Text style={styles.featureText}> Couple Friendly</Text>
                                </View>
                                <View style={styles.featureBadge}>
                                    <Ionicons name="card-outline" size={12} color="#fff" />
                                    <Text style={styles.featureText}> Local ID Accepted</Text>
                                </View>

                            </View>
                            <View style={styles.planWrapper}>
                                <View style={styles.planButtons}>
                                    <TouchableOpacity
                                        style={[styles.planBtn, plan === 'Hourly_Plan' && styles.planBtnActive]}
                                        onPress={() => setPlan('Hourly_Plan')}
                                    >
                                        <Text style={[styles.planText, plan === 'Hourly_Plan' && styles.planTextActive]}>Hourly Plan</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        style={[styles.planBtn, plan === 'Full_Day_Plan' && styles.planBtnActive]}
                                        onPress={() => setPlan('Full_Day_Plan')}
                                    >
                                        <Text style={[styles.planText, plan === 'Full_Day_Plan' && styles.planTextActive]}>Full Day Plan</Text>
                                    </TouchableOpacity>
                                </View>
                                <View>
                                    {
                                        plan == 'Full_Day_Plan' ? (

                                            rooms.map(item => (
                                                <View key={item.id}>
                                                    {renderRoom({ item })}
                                                </View>
                                            ))

                                        ) : (
                                            <View>
                                                <BookingCard hours="3Hrs" />
                                                <BookingCard hours="6Hrs" />
                                                <BookingCard hours="9Hrs" />
                                            </View>
                                        )
                                    }
                                </View>
                            </View>
                            {/* <Text style={styles.description}>{hotelDetails?.propertyDescription || "No description available."}</Text> */}
                            <View style={styles.amenitiesWrapper}>
                                <Text style={styles.amenitiesTitle}>Amenities</Text>
                                <View style={styles.amenitiesGrid}>
                                    {amenities.map(item => (
                                        <View key={item.id} style={[styles.amenityItem, styles.borderLeft, styles.borderTop]}>
                                            <Ionicons name={item.icon} size={22} color="#1e6dfb" />
                                            <Text style={styles.amenityText}>{item.label}</Text>
                                        </View>
                                    ))}
                                </View>
                            </View>
                            <NearByHotels
                                commonStyles={commonStyles}
                                styles={styles}
                                data={Array.from({ length: 5 })}
                                onViewAll={() => navigation.navigate("HotelDetails")} />
                            <View style={styles.policyWrapper}>
                                <Text style={styles.policyTitle}>Hotel Policies</Text>

                                <Text style={styles.policySubTitle}>Guest Policies</Text>

                                <View style={styles.bulletRow}>
                                    <View style={styles.bulletDot} />
                                    <Text style={styles.bulletText}>
                                        Unmarried couples above 18 years are allowed.
                                    </Text>
                                </View>

                                <View style={styles.bulletRow}>
                                    <View style={styles.bulletDot} />
                                    <Text style={styles.bulletText}>
                                        Valid government-issued photo ID is mandatory at check-in.
                                    </Text>
                                </View>

                                <View style={styles.bulletRow}>
                                    <View style={styles.bulletDot} />
                                    <Text style={styles.bulletText}>
                                        Local ID cards are accepted.
                                    </Text>
                                </View>

                                <Text style={styles.policySubTitle}>Restrictions</Text>

                                <View style={styles.bulletRow}>
                                    <View style={styles.bulletDot} />
                                    <Text style={styles.bulletText}>
                                        Smoking is not allowed inside the rooms.
                                    </Text>
                                </View>

                                <View style={styles.bulletRow}>
                                    <View style={styles.bulletDot} />
                                    <Text style={styles.bulletText}>
                                        Pets are allowed only in designated rooms.
                                    </Text>
                                </View>
                            </View>

                        </View>
                    </>
            }
        </ScrollView>
    );
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1
    },
    imageWrapper: {
        width: width,
        height: 360,
    },
    image: { width: width, height: '100%', resizeMode: "cover" },
    topButton: {
        width: width - 30,
        position: "absolute",
        top: StatusBar.currentHeight ? StatusBar.currentHeight + 10 : 40,
        left: 16,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    btnCircle: {
        backgroundColor: "#fff",
        borderRadius: 20,
        zIndex: 10,
        padding: 8,
    },
    thumbBox: {
        width: 80,
        height: 50,
        borderRadius: 6,
        marginRight: 8,
        borderWidth: 2,
        borderColor: "#fff",
    },
    thumbImg: {
        width: 76,
        height: 46,
        borderRadius: 6,
    },
    featureBadge: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "rgba(45, 48, 2, 0.75)",
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 6,
        marginRight: 8
    },
    featureText: {
        color: "#fff",
        fontSize: 11,
        fontWeight: "600"
    },
    content: { padding: 20 },
    title: { fontSize: 22, fontWeight: "700", marginBottom: 4 },
    location: {
        color: "#292929ff",
        fontSize: 14,
        lineHeight: 18
    },
    rating: { marginLeft: 6, fontSize: 14 },
    price: { fontSize: 18, fontWeight: "700" },
    oldPrice: {
        textDecorationLine: "line-through",
        marginLeft: 8,
        color: "#777",
    },
    discount: { marginLeft: 8, color: "green", fontWeight: "600" },
    description: { fontSize: 14, color: "#555", lineHeight: 20, marginTop: 15 },
    amenitiesWrapper: {
        marginTop: 1
    },
    amenitiesTitle: {
        fontSize: 18,
        fontWeight: "700",
        marginBottom: 8,
    },
    amenitiesGrid: {
        flexDirection: "row",
        flexWrap: "wrap",
        borderWidth: 1,
        borderColor: "#eee",
        borderRadius: 8,
        overflow: "hidden",
    },
    amenityItem: {
        width: "25%",
        height: 82,
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 6,
    },
    amenityText: {
        fontSize: 12,
        color: "#555",
        textAlign: "center",
        marginTop: 6,
        lineHeight: 16,
    },
    borderLeft: {
        borderLeftWidth: 1,
        borderColor: "#eee",
    },
    borderTop: {
        borderTopWidth: 1,
        borderColor: "#eee",
    },
    policyWrapper: {
        borderTopWidth: 1,
        borderTopColor: "#e5e5e5",
        paddingTop: 20,
        marginTop: 40,
    },
    policyTitle: {
        fontSize: 18,
        fontWeight: "700",
        marginBottom: 10,
    },
    policySubTitle: {
        fontSize: 16,
        fontWeight: "600",
        marginBottom: 8,
    },
    bulletRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 8,
    },
    bulletDot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: "#555",
        marginTop: 7,
        marginRight: 10,
    },
    bulletText: {
        flex: 1,
        fontSize: 14,
        color: "#555",
        lineHeight: 20,
    },
    planWrapper: { marginTop: 30 },
    planButtons: { flexDirection: 'row', borderRadius: 8, backgroundColor: '#ddd', borderRadius: 30, overflow: 'hidden', marginBottom: 14 },
    planBtn: { width: '50%', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 14 },
    planText: { color: '#000', fontWeight: '600' },
    planBtnActive: { backgroundColor: '#000' },
    planTextActive: { color: '#fff' },
    card: { marginBottom: 16, borderRadius: 8, overflow: 'hidden', borderWidth: 1, borderColor: '#eee' },
    roomImage: { width: '100%', height: 180 },
    roomName: { fontSize: 16, fontWeight: '700', margin: 10 },
    amenitiesRow: { flexDirection: 'row', marginHorizontal: 10, justifyContent: 'space-between' },
    price: { fontSize: 14, fontWeight: '700', margin: 10 },
    originalPrice: { textDecorationLine: 'line-through', fontWeight: '400', color: '#888' },
    discount: { color: 'green', fontWeight: '600' },
    bookBtn: { backgroundColor: '#1e6dfb', margin: 10, padding: 12, borderRadius: 6, alignItems: 'center' },
    bookBtnText: { color: '#fff', fontWeight: '600' },
    roomAmenityText: {
        fontSize: 12,
        color: "#555",
        lineHeight: 16
    },
    innerCard: {
        backgroundColor: "#fff",
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
        elevation: 2,
    },

    topRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },

    priceRow: {
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
    },

    sprice: {
        fontSize: 18,
        fontWeight: "700",
        color: "#0b5cff",
    },

    oldPrice: {
        fontSize: 14,
        color: "#999",
        textDecorationLine: "line-through",
    },

    off: {
        fontSize: 14,
        color: "#666",
    },

    hours: {
        fontSize: 16,
        fontWeight: "700",
        color: "#000",
    },

    flexible: {
        fontSize: 12,
        color: "#0b5cff",
        marginTop: 2,
    },

    taxText: {
        fontSize: 12,
        color: "#777",
        marginTop: 4,
        marginBottom: 12,
    },

    dropdown: {
        borderWidth: 1,
        borderColor: "#ccc",
        borderRadius: 8,
        paddingVertical: 12,
        paddingHorizontal: 14,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 14,
    },

    dropdownText: {
        fontSize: 14,
        color: "#555",
    },

    arrow: {
        fontSize: 16,
        color: "#555",
    },

    button: {
        backgroundColor: "#1a6df5",
        paddingVertical: 14,
        borderRadius: 8,
        alignItems: "center",
    },

    buttonText: {
        color: "#fff",
        fontSize: 16,
        fontWeight: "600",
    },
});
