import React from "react";
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

const NearByHotels = ({
    data = [],
    onViewAll,
    commonStyles,
}) => {
    return (
        <View style={commonStyles.mt_2}>
            <View style={[commonStyles.flexBetween, commonStyles.mb_3]}>
                <Text style={commonStyles.text_4}>{'Popular NearBy'}</Text>
            </View>
            <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.scrollContainer}
            >
                {data.map((item, index) => (
                    <View key={index} style={styles.itemCard}>
                        <Image
                            source={
                                item?.image
                                    ? { uri: item.image }
                                    : require("@assets/images/img-hotel.png")
                            }
                            style={styles.itemCardImage}
                        />

                        <View style={{ padding: 5 }}>
                            <Text style={[commonStyles.text_5, commonStyles.fwBold]}>
                                {item?.name || "Rrooms Elite H..."}
                            </Text>

                            <Text style={styles.itemLocation}>
                                {item?.location || "Sarnath, Varanasi"}
                            </Text>

                            <View style={commonStyles.flexBetween}>
                                <Text style={styles.itemPrice}>
                                    ₹{item?.price || 2200}/night
                                </Text>

                                <Text style={commonStyles.text_6}>
                                    <Icon name="star" size={14} color="#FFD700" />{" "}
                                    {item?.rating || 4.8}
                                </Text>
                            </View>
                        </View>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

export default NearByHotels;

const styles = StyleSheet.create({
    itemCard: {
        width: 180,
        backgroundColor: "#fff",
        borderRadius: 14,
        borderWidth: 1,
        borderColor: "#ddd",
        padding: 4,
        marginRight: 14
    },
    itemLocation: {
        fontSize: 12,
        color: '#666',
        marginVertical: 2,
    },
    itemPrice: {
        fontSize: 16,
        fontWeight: 'bold'
    },
})
