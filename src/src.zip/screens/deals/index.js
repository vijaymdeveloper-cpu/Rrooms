import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from "react-native";

const DealScreen = () => {

  return (
    <View style={styles.container}>
      <Text>Deals Screen</Text>
    </View>
  );
};

export default DealScreen;


const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: "#f4f6f8" },
});
