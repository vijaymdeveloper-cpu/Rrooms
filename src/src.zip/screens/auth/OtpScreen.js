import React, { useRef, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useDispatch, useSelector } from 'react-redux';
import OTPTextInput from "react-native-otp-textinput";
import services from "@api/services";
import { saveToken, saveUserData } from '@store/slices/authSlice'
import Ionicons from "react-native-vector-icons/Ionicons";
import { commonStyles } from '@assets/styles/commonStyles'

export default function OtpScreen({ route, navigation }) {

    const dispatch = useDispatch();
    const { mobile, name, email } = route.params || {};
    const [otp, setOtp] = useState("");
    const [error, setError] = useState("");
    const [otpMessage, setOtpMessage] = useState(false)

    const handleOtpChange = (code) => {
        setOtp(code);
        if (code.length < 4) {
            setError("OTP must be 4 digits");
        } else {
            setError("");
        }
    };

    const handleVerify = async () => {
        try {
            const payload = {
                name: name,
                email: email,
                mobile: mobile,
                otp: otp,
                platform: 2
            }
            const res = await services.verifyOtpService(payload)
            if (res.data.success) {
                dispatch(saveToken(res.data.token))
                dispatch(saveUserData(res.data.data))
                navigation.replace("Tabs");
            }
        }
        catch (err) {
            if (err?.response?.status === 400) {
                setOtpMessage(true)
            }
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View>
                <TouchableOpacity
                    onPress={() => {
                        if (navigation.canGoBack()) {
                            navigation.goBack();
                        }
                    }}
                    style={styles.backButton}>
                    <Ionicons name="arrow-back" size={28} />
                </TouchableOpacity>

                <Text style={styles.title}>Enter your</Text>
                <Text style={styles.title}>Verification Code</Text>

                <View style={styles.otpContainer}>
                    <OTPTextInput
                        inputCount={4}
                        handleTextChange={handleOtpChange}
                        containerStyle={{
                            width: "100%",
                            justifyContent: "space-between",
                            alignItems: "center"
                        }}
                        textInputStyle={{
                            borderWidth: 1,
                            borderColor: "#000",
                            borderRadius: 8,
                            width: 60,
                            height: 60,
                            textAlign: "center",
                            fontSize: 20,
                        }}
                    />

                    {
                        otpMessage && <Text style={commonStyles.error}>Invalid OTP. Please try again.</Text>
                    }
                    {error ? (
                        <Text style={commonStyles.error}>{error}</Text>
                    ) : null}
                </View>

                {/* Timer */}
                <Text style={styles.timer}>04:59</Text>

                {/* Info */}
                <Text style={styles.info}>
                    We send verification code to your{" "}
                    <Text style={styles.email}>{mobile ? `${mobile.slice(0, 2)}******${mobile.slice(-2)}` : ""}</Text>.
                    You can check your inbox.
                </Text>

                {/* Resend */}
                <TouchableOpacity>
                    <Text style={styles.resend}>I didn't received the code? Send again</Text>
                </TouchableOpacity>

                {/* Verify Button */}
                <TouchableOpacity style={styles.button} onPress={handleVerify}>
                    <Text style={styles.buttonText}>Verify</Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
}



const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        padding: 25
    },
    backButton: {
        marginBottom: 20
    },
    title: {
        fontSize: 26,
        fontWeight: "700",
    },
    otpContainer: {
        width: '100%',
        marginTop: 30
    },
    // otpBox: {
    //     width: 60,
    //     height: 60,
    //     borderWidth: 1,
    //     borderColor: "#f2c57c",
    //     borderRadius: 10,
    //     textAlign: "center",
    //     fontSize: 22,
    //     fontWeight: "600",
    //     color: "#f2a93b"
    // },
    timer: {
        marginTop: 20,
        color: "#f2a93b",
        fontWeight: "600"
    },
    info: {
        marginTop: 10,
        color: "#555"
    },
    email: {
        color: "#f2a93b"
    },
    resend: {
        marginTop: 10,
        color: "#f2a93b",
        fontWeight: "600"
    },
    button: {
        backgroundColor: "#f2a93b",
        paddingVertical: 18,
        borderRadius: 6,
        alignItems: "center",
        marginTop: 30
    },
    buttonText: {
        color: "#fff",
        fontSize: 18,
        fontWeight: "600"
    }
});
