import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useForm, Controller } from "react-hook-form";
import services from "@api/services";
import { commonStyles } from '@assets/styles/commonStyles';

export default function LoginScreen({ navigation }) {

  const { control, handleSubmit, formState: { errors } } = useForm();

  const handleSendOtp = async (data) => {
    try {
      const payload = {
        mobile: data.mobile
      }
      const res = await services.sendOtpService(payload)
      if (res.data.status) {
        if (res?.data?.isNewUser) {
          navigation.navigate('Signup', { mobile: data.mobile })
        }
        else {
          navigation.navigate('Otp',
            {
              mobile: data.mobile,
              name: res?.data?.data?.name,
              email: res?.data?.data?.email
            }
          )
        }
      }
    }
    catch (err) { console.log(err) }
  }

  return (
    <ImageBackground
      source={require("@assets/images/bg-screen.png")}
      style={styles.bg}
      resizeMode="cover">
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 0}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          <SafeAreaView style={styles.container}>
            <View style={styles.topContainer}>
              <Image
                source={require("@assets/images/logo.png")}
                style={styles.logo}
              />

              <Text style={styles.tagline}>
                You have got place to be & people to see..
              </Text>
              <Text style={styles.subTagline}>
                So go anywhere with RRooms..
              </Text>
            </View>

            {/* Bottom Section */}
            <View style={styles.bottomContainer}>
              <Text style={styles.title}>Login/Signup</Text>

              <Text style={styles.desc}>
                Tap "Continue" to get an SMS confirmation to help you user{" "}
                <Text style={{ color: "#FF8C00", fontWeight: "600" }}>
                  RRooms
                </Text>
                . We would like your phone number.
              </Text>

              <View style={commonStyles.mb_1}>
                <Text style={styles.label}>Mobile Number</Text>
                <Controller
                  control={control}
                  name="mobile"
                  rules={{
                    required: "Mobile number required",
                    minLength: { value: 10, message: "10 digit number required" },
                    maxLength: { value: 10, message: "10 digit number required" },
                  }}
                  render={({ field: { onChange, value } }) => (
                    <TextInput
                      style={styles.input}
                      placeholder="Enter Mobile Number"
                      keyboardType="number-pad"
                      maxLength={10}
                      value={value}
                      onChangeText={onChange}
                    />
                  )}
                />
                {errors.mobile && (
                  <Text style={commonStyles.error}>{errors.mobile.message}</Text>
                )}
              </View>
              <TouchableOpacity
                style={[styles.button]}
                onPress={handleSubmit(handleSendOtp)}>
                <Text style={styles.buttonText}>Continue</Text>
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        </ScrollView>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}


const styles = StyleSheet.create({
  bg: {
    flex: 1,
    paddingTop: 10
  },
  container: {
    flex: 1,
    // backgroundColor: "#F5FAFF",
  },

  topContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },

  logo: {
    width: 60,
    height: 80,
    resizeMode: "contain",
    marginBottom: 16,
  },

  tagline: {
    fontSize: 16,
    color: "#333",
    textAlign: "center",
  },

  subTagline: {
    fontSize: 16,
    color: "#333",
    marginTop: 4,
  },

  bottomContainer: {
    flex: 2,
    // backgroundColor: "#fff",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    padding: 25,
  },

  title: {
    fontSize: 30,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 12,
  },

  desc: {
    fontSize: 18,
    lineHeight: 26,
    color: "#666",
    textAlign: "center",
    marginBottom: 44,
  },

  label: {
    fontSize: 18,
    fontWeight: "600",
    color: '#3C4043',
    marginBottom: 6,
  },

  input: {
    borderWidth: 1,
    borderColor: "#4D9CFF",
    borderRadius: 6,
    height: 64,
    padding: 14,
    fontSize: 16,
    marginBottom: 20,
  },

  button: {
    backgroundColor: "#1E6DFB",
    paddingVertical: 18,
    borderRadius: 6,
    alignItems: "center",
  },

  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },

  skip: {
    fontSize: 18,
    textAlign: "center",
    color: "#8E949A",
    marginTop: 16,
  },
});
