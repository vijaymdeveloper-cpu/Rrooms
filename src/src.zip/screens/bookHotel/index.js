import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import Header from '@components/Header'
import { commonStyles } from '@assets/styles/commonStyles'

const Counter = ({ label, value, setValue }) => (
  <View style={styles.counterRow}>
    <Text style={styles.counterLabel}>{label}</Text>

    <View style={styles.counterBox}>
      <TouchableOpacity
        style={styles.counterBtn}
        onPress={() => value > 0 && setValue(value - 1)}
      >
        <Text style={styles.counterText}>−</Text>
      </TouchableOpacity>

      <Text style={styles.counterValue}>{value}</Text>

      <TouchableOpacity
        style={styles.counterBtn}
        onPress={() => setValue(value + 1)}
      >
        <Text style={styles.counterText}>+</Text>
      </TouchableOpacity>
    </View>
  </View>
);

const BookHotelScreen = ({ navigation }) => {
  const [adult, setAdult] = useState(2);
  const [child, setChild] = useState(0);
  const [room, setRoom] = useState(1);
  const [coupon, setCoupon] = useState("");

  return (
    <ScrollView style={commonStyles.screenWrapper}>

      <Header showBack={true} />

      <View style={[styles.dateRow, commonStyles.rowBetween]}>
        <View style={styles.dateBox}>
          <Text style={styles.dateLabel}>Check-in</Text>
          <Text style={styles.dateValue}>22 Dec 2025</Text>
        </View>
        <View style={styles.dateBox}>
          <Text style={styles.dateLabel}>Check-out</Text>
          <Text style={styles.dateValue}>23 Dec 2025</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={[commonStyles.text_5, commonStyles.fwMedium]}>Hotel Grand Palace</Text>
        <View style={[commonStyles.row, commonStyles.itemsCenter, commonStyles.mt_1]}>
          <Ionicons name="location-outline" size={14} color="#777" />
          <Text style={styles.locationText}>Connaught Place, New Delhi</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Guests & Rooms</Text>
        <Counter label="Adults" value={adult} setValue={setAdult} />
        <Counter label="Children" value={child} setValue={setChild} />
        <Counter label="Rooms" value={room} setValue={setRoom} />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Price Details</Text>

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Room Tariff</Text>
          <Text style={styles.priceValue}>₹ 2,000</Text>
        </View>

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Instant Discount</Text>
          <Text style={[styles.priceValue, { color: "green" }]}>− ₹ 300</Text>
        </View>

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Taxes & Fees</Text>
          <Text style={styles.priceValue}>₹ 200</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.priceRow}>
          <Text style={styles.totalLabel}>Total Payable</Text>
          <Text style={styles.totalValue}>₹ 1,900</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Apply Coupon</Text>
        <View style={commonStyles.row}>
          <TextInput
            placeholder="Enter coupon code"
            style={commonStyles.input}
            value={coupon}
            onChangeText={setCoupon}
          />
          <TouchableOpacity style={[commonStyles.btn, commonStyles.btnDark]}>
            <Text style={commonStyles.btnText}>Apply</Text>
          </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity style={[commonStyles.btn, commonStyles.btnPrimary]} onPress={()=> navigation.navigate('BookingConfirmed')}>
        <Text style={commonStyles.btnText}>Continue Booking</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default BookHotelScreen;


const styles = StyleSheet.create({
  dateRow: {
    marginVertical: 12
  },
  dateBox: {
    backgroundColor: "rgba(255,255,255,0.6)",
    width: "48%",
    padding: 14,
  },
  dateLabel: {
    fontSize: 12,
    color: "#777",
  },
  dateValue: {
    fontSize: 15,
    fontWeight: "600",
    marginTop: 4,
  },
  card: {
    backgroundColor: "rgba(255,255,255,0.6)",
    padding: 16,
    marginBottom: 12,
  },
  locationText: {
    fontSize: 12,
    color: "#777",
    marginLeft: 4,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "600",
    marginBottom: 12,
  },
  counterRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  counterLabel: {
    fontSize: 14,
  },
  counterBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#DDD",
    borderRadius: 8,
  },
  counterBtn: {
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  counterText: {
    fontSize: 18,
  },
  counterValue: {
    paddingHorizontal: 12,
    fontSize: 15,
  },
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: "#555",
  },
  priceValue: {
    fontSize: 14,
  },
  divider: {
    height: 1,
    backgroundColor: "#EEE",
    marginVertical: 10,
  },
  totalLabel: {
    fontSize: 15,
    fontWeight: "600",
  },
  totalValue: {
    fontSize: 16,
    fontWeight: "700",
  }
});
