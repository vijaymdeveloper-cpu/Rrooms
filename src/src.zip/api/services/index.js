import api from '../../api/client'
import dictionary from '../directory'

const Services = {

    sendOtpService: (data) => {
        return api.post(dictionary.sendOtp(), data)
    },
    verifyOtpService: (data) => {
        return api.post(dictionary.verifyOtp(), data)
    },
    getCustomerProfileService: (id) => {
        return api.get(dictionary.getCustomerProfile(id))
    },
    editCustomerService: (id, data) => {
        return api.put(dictionary.editCustomer(id), data)
    },
    customerWalletService: (id) => {
        return api.get(dictionary.customerWallet(id))
    },
    getBookingsService: (id, page, limit) => {
        return api.get(dictionary.getBookings(id, page, limit))
    },

    allCitiesService: () => {
        return api.get(dictionary.allCities())
    },
    allStatesService: () => {
        return api.get(dictionary.allStates())
    },
    roomsCategoryService: () => {
        return api.get(dictionary.roomsCategory())
    },
    propertyCategoryService: () => {
        return api.get(dictionary.propertyCategory())
    },

    searchPropertiesService: (params) => {
        return api.get(params ? dictionary.searchProperties() + params : dictionary.searchProperties())
    },
    singlePropertyService: (id) => {
        return api.get(dictionary.singleProperty(id))
    },
    getAmentiesService: () => {
        return api.get(dictionary.getAmenties())
    },
    nearByPropertiesService: (id) => {
        return api.get(dictionary.nearByProperties(id))
    },

    getTaxService: (id) => {
        return api.get(dictionary.getTax(id))
    },
    checkRoomAvailabilityService: (data) => {
        return api.post(dictionary.checkRoomAvailability(), data)
    },

    bookHotelService: (data) => {
        return api.post(dictionary.bookHotel(), data)
    },
    changeBookingStatusService: (bookingId, data) => {
        return api.post(dictionary.changeBookingStatus(bookingId), data)
    },
    createBookingLogService: (data) => {
        return api.post(dictionary.createBookingLog(), data)
    },

}

export default Services