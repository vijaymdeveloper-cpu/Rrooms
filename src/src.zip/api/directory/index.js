const Dictionary = {

    sendOtp: ()=> `auth/otpGen`,
    verifyOtp: ()=> `auth/otpVerify`,
    getCustomerProfile: (id)=> `auth/customers/${id}`,
    editCustomer: (id)=> `auth/update-user/${id}`,
    customerWallet: (id)=> `auth/user-wallet?user_id=${id}`,
    getBookings: (id, page, limit)=> `booking/room-booking/by-user/${id}?page=${page}&limit=${limit}`,

    allCities: ()=> `country/city`,
    allStates: ()=> `country/state`,
    roomsCategory: ()=> `rrooms-property/rroom-category`,
    propertyCategory: ()=> `rrooms-property/property-category`,

    searchProperties: () => `rrooms-property/search`,
    singleProperty: (id) => `rrooms-property/property/${id}`,
    getAmenties: ()=> `rrooms-property/amenities`,
    nearByProperties: (id)=> `booking/nearest-property/${id}`,

    getTax: (id)=> `rrooms-property/service-tax/${id}`,
    checkRoomAvailability: ()=> `booking/room-availability/check`,

    bookHotel: ()=> `booking/room-booking`,
    changeBookingStatus: (bookingId)=> `booking/room-booking/${bookingId}`,
    createBookingLog: ()=> `booking/booking-logs`
    
}

export default Dictionary;