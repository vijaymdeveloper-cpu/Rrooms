export const POPULAR_CITIES = [
    "Lucknow",
    "Ayodhya",
    "Agra",
    "Bareilly",
    "Varanasi",
    "Prayagraj",
    "Vrindavan",
    "Chitrakoot",
    "Kanpur",
    "Sitapur",
];

export const CITY_PRIORITY = [
    "Lucknow",
    "Agra",
    "Bareilly",
    "Prayagraj",
];

export const PROPERTY_CATEGORY_COLORS = {
    1: '#1FCC75',
    2: '#5069f1',
    3: '#E91E63',
    4: '#FF9800',
    5: '#9C27B0'
}

export const TRAVEL_OPTIONS = [


    {
        title: "Business Travel",
        subtitle: "All India, 4,534 RRooms",
        id: 2,
        img: 'https://rrooms.in/static/media/img-business-travel.6ffe8a65244be43ceedf.png',
    },
    {
        title: "Couple Friendly",
        subtitle: "All India, 4,534 RRooms",
        id: 7,
        img: 'https://rrooms.in/static/media/img-couple-friendly.c940fa7995ee210119be.png',
    },
    {
        title: "Family Vacation",
        subtitle: "All India, 4,534 RRooms",
        id: 3,
        img: 'https://rrooms.in/static/media/img-family-vacation.9587ab26f28862025eaf.png',
    },
    {
        title: "Group Travel",
        subtitle: "All India, 4,534 RRooms",
        id: 5,
        img: 'https://rrooms.in/static/media/img-group-travel.e0c9c2134adfd8d700a7.png',
    },
    {
        title: "Solo Traveler",
        subtitle: "All India, 4,534 RRooms",
        id: 6,
        img: 'https://rrooms.in/static/media/img-solo-travel.1db8332c264f13bf9452.png',
    },
    {
        title: "Hourly-Stays",
        subtitle: "All India, 4,534 RRooms",
        id: 8,
        img: 'https://rrooms.in/static/media/img-hourly-stay.f6e68a2fa6f02779027d.jpeg',
    },
]